#pragma once

int gw_hash(const char *str);