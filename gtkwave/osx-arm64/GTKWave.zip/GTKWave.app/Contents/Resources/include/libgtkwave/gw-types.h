#pragma once

typedef struct _GwBitAttributes GwBitAttributes;
typedef struct _GwBits GwBits;
typedef struct _GwBitVector GwBitVector;
typedef struct _GwExpandReferences GwExpandReferences;
typedef struct _GwFac GwFac;
typedef struct _GwHistEnt GwHistEnt;
typedef struct _GwNode GwNode;
typedef struct _GwSymbol GwSymbol;
typedef struct _GwTrace GwTrace;
typedef struct _GwTreeNode GwTreeNode;
typedef struct _GwVectorEnt GwVectorEnt;
